import { Metadata } from "next";
import { AuthLayout } from "@/components/auth/auth-layout";
import { LoginForm } from "@/components/auth/login-form";

export const metadata: Metadata = {
  title: "Sign In | FixBari",
  description: "Sign in to your FixBari account",
};

export default function LoginPage() {
  return (
    <AuthLayout title="Welcome Back" subtitle="Please enter your detail">
      <LoginForm />
    </AuthLayout>
  );
}
